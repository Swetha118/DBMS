package main;





import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class fEMPLOYEE {

	private JFrame frame;
	private JTextField nametxt;
	private JTextField typetxt;
	private JTextField salarytxt;
	private JTextField contacttxt;
	private JTextField EIDtxt;
	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	private JTable table_1;
	
 
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Pass#123");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }

	/**
	 * Create the application.
	 */
	public fEMPLOYEE() {
		initialize();
		this.frame.setVisible(true);
		Connect();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.PINK);
		frame.setBounds(100, 100, 1123, 632);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("EMPLOYEE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(427, -24, 337, 111);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(119, 75, 436, 383);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel btnNewButton = new JLabel("Ename");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(38, 55, 127, 38);
		panel.add(btnNewButton);
		
		JLabel btnNewButton_1 = new JLabel("etype");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_1.setBounds(38, 140, 127, 38);
		panel.add(btnNewButton_1);
		
		JLabel btnNewButton_2 = new JLabel("Esalary");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBounds(38, 155, 127, 38);
		panel.add(btnNewButton_2);
		
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBounds(38, 222, 127, 33);
		panel.add(btnNewButton_2);
		
		JLabel btnNewButton_3 = new JLabel("Econtact");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_3.setBounds(38, 311, 127, 33);
		panel.add(btnNewButton_3);
		
		nametxt = new JTextField();
		nametxt.setBounds(175, 57, 183, 38);
		panel.add(nametxt);
		nametxt.setColumns(10);
		
		typetxt = new JTextField();
		typetxt.setColumns(10);
		typetxt.setBounds(175, 147, 183, 33);
		panel.add(typetxt);
		
		salarytxt = new JTextField();
		salarytxt.setColumns(10);
		salarytxt.setBounds(175, 222, 183, 33);
		panel.add(salarytxt);
		
		contacttxt = new JTextField();
		contacttxt.setColumns(10);
		contacttxt.setBounds(175, 311, 172, 33);
		panel.add(contacttxt);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(148, 510, 383, 60);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel btnNewButton_2_1 = new JLabel("EID");
		btnNewButton_2_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2_1.setBounds(31, 11, 137, 38);
		panel_1.add(btnNewButton_2_1);
		
		EIDtxt = new JTextField();
		EIDtxt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					String EID,ename,etype,esalary,econtact;
					EID=EIDtxt.getText();
					ename=nametxt.getText();
					etype=typetxt.getText();
					esalary=salarytxt.getText();
					econtact=contacttxt.getText();
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from employee where E_ID=(?)");
	            	 pstmt1.setString(1, EID);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            	 EIDtxt.setText(rs.getString(1));
	            	 nametxt.setText(rs.getString(2));
	            	 typetxt.setText(rs.getString(3));
	            	 salarytxt.setText(rs.getString(4));
	            	 contacttxt.setText(rs.getString(5));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		
		EIDtxt.setColumns(10);
		EIDtxt.setBounds(201, 18, 172, 33);
		panel_1.add(EIDtxt);
		
		JButton btnNewButton_4 = new JButton("SAVE");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					
					String EID,ename,etype,esalary,econtact;
					EID=EIDtxt.getText();
					ename=nametxt.getText();
					etype=typetxt.getText();
					esalary=salarytxt.getText();
					econtact=contacttxt.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into employee values(?,?,?,?,?)");
		            	        pstmt.setString(1, EID);
		            	        pstmt.setString(2,etype);
		            	        pstmt.setString(3,ename);
		            	        pstmt.setString(4,esalary);
		            	        pstmt.setString(5,econtact);
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_4.setBounds(730, 127, 111, 55);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("VIEW");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_5) {
					fviewemployee vs=new fviewemployee();
				}
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_5.setBounds(743, 428, 135, 45);
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("UPDATE");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_6) {
					String EID,ename,etype,esalary,econtact;
					EID=EIDtxt.getText();
					ename=nametxt.getText();
					etype=typetxt.getText();
					esalary=salarytxt.getText();
					econtact=contacttxt.getText();
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  employee set E_TYPE=(?),E_NAME=(?),E_SALARY=(?),E_CONTACT=(?) where E_ID=(?)");
	            	 pstmt.setString(5, EID);
         	        pstmt.setString(1,etype);
         	        pstmt.setString(2,ename);
         	        pstmt.setString(3,esalary);
         	        pstmt.setString(4,econtact);
	            	        int i=pstmt.executeUpdate();  
				    //txtmsg.append("\nInserted " + i + " rows successfully");
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_6.setBounds(739, 243, 122, 41);
		frame.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_6_1 = new JButton("DELETE");
		btnNewButton_6_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_6_1) {
					String EID,ename,etype,esalary,econtact;
					EID=EIDtxt.getText();
					ename=nametxt.getText();
					etype=typetxt.getText();
					esalary=salarytxt.getText();
					econtact=contacttxt.getText();
				
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from employee where E_ID=(?)");
		            	        pstmt.setString(1, EID);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnNewButton_6_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_6_1.setBounds(743, 342, 135, 32);
		frame.getContentPane().add(btnNewButton_6_1);
		
		
	}
}

