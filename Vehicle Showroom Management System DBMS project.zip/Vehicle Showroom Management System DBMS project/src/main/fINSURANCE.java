package main;



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Color;

public class fINSURANCE {

	private JFrame frame;
	private JTextField nametxt;
	private JTextField contacttxt;
	private JTextField IDtxt;

	
	/**
	 * Create the application.
	 */
	public fINSURANCE() {
		initialize();
		this.frame.setVisible(true);
		Connect();
	}
	
	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	
	
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Pass#123");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.CYAN);
		frame.setBounds(100, 100, 1119, 606);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("INSURANCE");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(452, 11, 153, 37);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(208, 116, 338, 258);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(20, 39, 84, 38);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Contact");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(20, 170, 84, 38);
		panel.add(lblNewLabel_1_1);
		
		nametxt = new JTextField();
		nametxt.setBounds(114, 39, 163, 38);
		panel.add(nametxt);
		nametxt.setColumns(10);
		
		contacttxt = new JTextField();
		contacttxt.setColumns(10);
		contacttxt.setBounds(114, 179, 163, 38);
		panel.add(contacttxt);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(226, 496, 312, 62);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1_2 = new JLabel("VID");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(10, 11, 84, 38);
		panel_1.add(lblNewLabel_1_2);
		
		IDtxt = new JTextField();
		IDtxt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					String name,contact,ID;
					name=nametxt.getText();
					contact=contacttxt.getText();
					ID=IDtxt.getText();
					
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from insurance where V_ID=(?)");
	            	 pstmt1.setString(1, ID);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            		 IDtxt.setText(rs.getString(2));
	            	nametxt.setText(rs.getString(1));
	            	
	            	contacttxt.setText(rs.getString(3));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		IDtxt.setColumns(10);
		IDtxt.setBounds(113, 20, 163, 38);
		panel_1.add(IDtxt);
		
		JButton btnNewButton = new JButton("SAVE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					
					String name,contact,ID;
					name=nametxt.getText();
					contact=contacttxt.getText();
					ID=IDtxt.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into insurance values (?,?,?)");
		            	        pstmt.setString(1, name);
		            	        pstmt.setString(2,ID);
		            	        pstmt.setString(3,contact);
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(771, 134, 137, 37);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("VIEW");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnExit) {
					fviewinsurance emp=new fviewinsurance();
				}
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnExit.setBounds(781, 452, 137, 37);
		frame.getContentPane().add(btnExit);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnUpdate) {
					String name,contact,ID;
					name=nametxt.getText();
					contact=contacttxt.getText();
					ID=IDtxt.getText();
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  insurance set  C_NAME=(?),C_CONTACT=(?) where V_ID=(?)");
	            	        pstmt.setString(3,ID);
	            	        pstmt.setString(1,name);
	            	        pstmt.setString(2,contact);
	            	        int i=pstmt.executeUpdate();  
				    //txtmsg.append("\nInserted " + i + " rows successfully");
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnUpdate.setBounds(781, 247, 137, 37);
		frame.getContentPane().add(btnUpdate);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnDelete) {
					String name,contact,ID;
					name=nametxt.getText();
					contact=contacttxt.getText();
					ID=IDtxt.getText();
					
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from insurance where V_ID=(?)");
		            	        pstmt.setString(1, ID);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});

		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDelete.setBounds(781, 352, 137, 37);
		frame.getContentPane().add(btnDelete);
	}

}

