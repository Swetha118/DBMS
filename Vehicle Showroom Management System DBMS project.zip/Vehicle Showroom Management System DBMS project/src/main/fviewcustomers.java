package main;



import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

class fviewcustomers{

		private JFrame frame;
		private JTable table;
	    String[][] tbl=new String[100][100];
	    Connection con;
		Statement stmt;
		ResultSet rs;
		private JLabel lblNewLabel;
		private JLabel lblNewLabel_1;
		private JLabel lblNewLabel_3;
		private JLabel lblNewLabel_4;
		private JLabel lblNewLabel_5;
		/**
		 * Create the application.
		 */
		fviewcustomers() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Pass#123");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 797, 503);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JTextPane txtpnOfficerDetails = new JTextPane();
			txtpnOfficerDetails.setFont(new Font("Tahoma", Font.BOLD, 21));
			txtpnOfficerDetails.setText("employee details");
			txtpnOfficerDetails.setBounds(227, 25, 239, 32);
			frame.getContentPane().add(txtpnOfficerDetails);
			try {
				ResultSet rs=stmt.executeQuery("select * from customers");
				
				int i=0;
				while(rs.next()) {
					
					
					
					tbl[i][0]=rs.getString(1);
					tbl[i][1]=rs.getString(2);

					tbl[i][2]=rs.getString(3); 
					tbl[i][3]=rs.getString(4); 
					tbl[i][4]=rs.getString(5); 
					
				
					i=i+1;
					
				}
				
				
			
			table = new JTable();
			table.setRowSelectionAllowed(false);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				tbl,
				new String[] {
					"OFFICER ID", "NAME", "PHONENO"," SALARy","CONTACT"
				}
			));
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setBounds(29, 137, 723, 121);
			frame.getContentPane().add(table);
			
			lblNewLabel = new JLabel("NAME");
			lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel.setBounds(48, 101, 235, 26);
			frame.getContentPane().add(lblNewLabel);
			
			lblNewLabel_1 = new JLabel("CONTACT");
			lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_1.setBounds(200, 92, 199, 45);
			frame.getContentPane().add(lblNewLabel_1);
			
			lblNewLabel_3 = new JLabel("MAIL");
			lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_3.setBounds(350, 101, 164, 26);
			frame.getContentPane().add(lblNewLabel_3);
			

			lblNewLabel_4 = new JLabel("ADDRESS");
			lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_4.setBounds(500, 101, 164, 26);
			frame.getContentPane().add(lblNewLabel_4);
			

			lblNewLabel_5 = new JLabel("VID");
			lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 17));
			lblNewLabel_5.setBounds(600, 101, 164, 26);
			frame.getContentPane().add(lblNewLabel_5);
			}
			catch(Exception E)
	        { 
	        	System.out.println(E);
	        }  
			
			
		}
	}

 
