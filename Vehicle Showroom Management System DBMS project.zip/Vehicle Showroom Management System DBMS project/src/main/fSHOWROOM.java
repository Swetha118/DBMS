package main;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JPanel;
import javax.swing.border.MatteBorder;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.border.TitledBorder;

import com.sun.jdi.connect.spi.Connection;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class fSHOWROOM {

	private JFrame frame;
	private JTextField txtSRaddress;
	private JTextField txtvehicles;
	private JTable table;
	
	private JTextField txtSRID;
     
	

	
  

	/**
	 * Create the application.
	 */
	public fSHOWROOM() {
		initialize();
		this.frame.setVisible(true);
		Connect();
	}

	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	private JTable table_1;
 
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Pass#123");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 1120, 618);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("SHOWROOM");
		lblNewLabel.setBounds(416, 11, 358, 43);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBorder(new MatteBorder(1, 1, 1, 1, (Color) new Color(0, 0, 0)));
		panel.setBounds(80, 64, 408, 312);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Showroomaddress");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_2.setBounds(10, 72, 202, 49);
		panel.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("noof vehicles");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3.setBounds(20, 169, 144, 26);
		panel.add(lblNewLabel_3);
		
		txtSRaddress = new JTextField();
		txtSRaddress.setBounds(239, 85, 147, 31);
		panel.add(txtSRaddress);
		txtSRaddress.setColumns(10);
		
		txtvehicles = new JTextField();
		txtvehicles.setBounds(226, 171, 147, 31);
		panel.add(txtvehicles);
		txtvehicles.setColumns(10);
		
		
		JButton btnNewButton = new JButton("SAVE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					
					String SRID,SRaddress,vehicles;
					SRID=txtSRID.getText();
					SRaddress=txtSRaddress.getText();
					vehicles=txtvehicles.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into showroom values (?,?,?)");
		            	        pstmt.setString(1, SRID);
		            	        pstmt.setString(2,SRaddress);
		            	        pstmt.setString(3,vehicles);
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(104, 388, 175, 54);
		frame.getContentPane().add(btnNewButton);
		
		
		
		table = new JTable();
		table.setBounds(714, 327, 1, 1);
		frame.getContentPane().add(table);
		
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(64, 486, 330, 53);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_3_1 = new JLabel("SRID");
		lblNewLabel_3_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_3_1.setBounds(10, 11, 144, 26);
		panel_1.add(lblNewLabel_3_1);
		
		txtSRID = new JTextField();
		txtSRID.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					String SRID,SRaddress,vehicles;
					SRID=txtSRID.getText();
					SRaddress=txtSRaddress.getText();
					vehicles=txtvehicles.getText();
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from showroom where sr_id=(?)");
	            	 pstmt1.setString(1, SRID);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            	 txtSRID.setText(rs.getString(1));
	            	 txtSRaddress.setText(rs.getString(2));
	            	 txtvehicles.setText(rs.getString(3));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		txtSRID.setColumns(10);
		txtSRID.setBounds(126, 13, 147, 31);
		panel_1.add(txtSRID);
		
		JButton btnNewButton_1 = new JButton("UPDATE");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_1) {
				String SRID,SRaddress,vehicles;
				SRID=txtSRID.getText();
				SRaddress=txtSRaddress.getText();
				vehicles=txtvehicles.getText();
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  showroom set  SR_ADDRESS=(?),NO_OF_VEHICLES=(?) where SR_ID=(?)");
	            	        pstmt.setString(3, SRID);
	            	        pstmt.setString(1,SRaddress);
	            	        pstmt.setString(2,vehicles);
	            	        int i=pstmt.executeUpdate();  
				    //txtmsg.append("\nInserted " + i + " rows successfully");
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_1.setBounds(616, 83, 175, 57);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("DELETE");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_2) {
					String SRID,SRaddress,vehicles;
					SRID=txtSRID.getText();
					SRaddress=txtSRaddress.getText();
					vehicles=txtvehicles.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from showroom where SR_ID=(?)");
		            	        pstmt.setString(1, SRID);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBounds(628, 198, 146, 54);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("view");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_3) {
					fviewshowroom vs=new fviewshowroom();
				}
			}
		});
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton_3.setBounds(638, 327, 136, 49);
		frame.getContentPane().add(btnNewButton_3);

	}
}
