package main;



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Color;

public class FLOANS {

	private JFrame frame;
	private JTextField txtname;
	private JTextField txtcontact;
	private JTextField txtvehicleID;
	private JTextField txtloanID;
	private JTextField txtamount;

	
	/**
	 * Create the application.
	 */
	public FLOANS() {
		initialize();
		this.frame.setVisible(true);
		Connect();
	}
	
	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	
 
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Pass#123");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.ORANGE);
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 20));
		frame.setBounds(100, 100, 1161, 618);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("LOANS");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel.setBounds(483, 22, 149, 29);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(31, 44, 442, 326);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(34, 30, 82, 24);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("contact");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(23, 118, 108, 24);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("vehicleID");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(23, 200, 108, 24);
		panel.add(lblNewLabel_1_2);
		
		txtname = new JTextField();
		txtname.setBounds(172, 23, 195, 46);
		panel.add(txtname);
		txtname.setColumns(10);
		
		txtcontact = new JTextField();
		txtcontact.setColumns(10);
		txtcontact.setBounds(172, 104, 195, 36);
		panel.add(txtcontact);
		
		txtvehicleID = new JTextField();
		txtvehicleID.setColumns(10);
		txtvehicleID.setBounds(172, 198, 195, 36);
		panel.add(txtvehicleID);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Amount");
		lblNewLabel_1_1_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1_2.setBounds(23, 274, 82, 24);
		panel.add(lblNewLabel_1_1_2);
		
		txtamount = new JTextField();
		txtamount.setColumns(10);
		txtamount.setBounds(172, 267, 195, 47);
		panel.add(txtamount);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(46, 509, 388, 61);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1_3 = new JLabel("LOAN ID");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_3.setBounds(10, 22, 111, 24);
		panel_1.add(lblNewLabel_1_3);
		
		txtloanID = new JTextField();
		txtloanID.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					String LID,name,contact,VID,amount;
					LID=txtloanID.getText();
					name=txtname.getText();
					contact=txtcontact.getText();
					VID=txtvehicleID.getText();
					amount=txtamount.getText();
					
					
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from loans where l_ID=(?)");
	            	 pstmt1.setString(1, LID);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            	 txtloanID.setText(rs.getString(1));
	            	txtname.setText(rs.getString(2));
	            	 txtcontact.setText(rs.getString(3));
	            	txtvehicleID.setText(rs.getString(4));
	            	 txtamount.setText(rs.getString(5));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		txtloanID.setColumns(10);
		txtloanID.setBounds(143, 20, 164, 37);
		panel_1.add(txtloanID);
		
		JButton btnNewButton = new JButton("SAVE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					
					String LID,name,contact,VID,amount;
					LID=txtloanID.getText();
					name=txtname.getText();
					contact=txtcontact.getText();
					VID=txtvehicleID.getText();
					amount=txtamount.getText();
					
					
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into loans values (?,?,?,?,?)");
		            	        pstmt.setString(1, LID);
		            	        pstmt.setString(2,name);
		            	        pstmt.setString(3,contact);
		            	        pstmt.setString(4,VID);
		            	        pstmt.setString(5,amount);
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(721, 177, 109, 41);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("VIEW");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnExit) {
					fviewloans vs=new fviewloans();
				}
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnExit.setBounds(721, 91, 109, 47);
		frame.getContentPane().add(btnExit);
		
		JButton btnDelete = new JButton("DELETE");
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnDelete) {
					
					try {
						
						String LID,name,contact,VID,amount;
						LID=txtloanID.getText();
						name=txtname.getText();
						contact=txtcontact.getText();
						VID=txtvehicleID.getText();
						amount=txtamount.getText();
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from loans where L_ID=(?)");
		            	        pstmt.setString(1, LID);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDelete.setBounds(724, 280, 135, 48);
		frame.getContentPane().add(btnDelete);
		
		JButton btnUpdate = new JButton("UPDATE");
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnUpdate) {

					String LID,name,contact,VID,amount;
					LID=txtloanID.getText();
					name=txtname.getText();
					contact=txtcontact.getText();
					VID=txtvehicleID.getText();
					amount=txtamount.getText();
				
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  loans set  C_NAME=(?),C_CONTACT=(?),V_ID=(?),L_AMOUNT=(?) where L_ID=(?)");
	            	        pstmt.setString(5, LID);
	            	        pstmt.setString(1,name);
	            	        pstmt.setString(2,contact);
	            	        pstmt.setString(3,VID);
	            	        pstmt.setString(4,amount);
	            	        int i=pstmt.executeUpdate();  
				    //txtmsg.append("\nInserted " + i + " rows successfully");
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnUpdate.setBounds(743, 412, 135, 48);
		frame.getContentPane().add(btnUpdate);
	}
}
