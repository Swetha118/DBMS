package main;



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTable;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JTextArea;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.Color;

public class fvehicles {

	private JFrame frame;

	

	/**
	 * Create the application.
	 */
	public fvehicles() {
		initialize();
	this.frame.setVisible(true);
	 Connect();
	}
	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	private JTable table_1;
 
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Pass#123");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.LIGHT_GRAY);
		frame.setBounds(100, 100, 1128, 627);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("VEHICLES");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(447, 11, 192, 46);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(204, 80, 387, 316);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Model");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(22, 60, 102, 41);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Colour");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(22, 129, 102, 41);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Weight");
		lblNewLabel_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1_1.setBounds(22, 217, 102, 41);
		panel.add(lblNewLabel_1_1_1);
		
		JTextArea txtmodel = new JTextArea();
		txtmodel.setBounds(122, 60, 160, 34);
		panel.add(txtmodel);
		
		JTextArea txtcolour = new JTextArea();
		txtcolour.setBounds(122, 129, 160, 34);
		panel.add(txtcolour);
		
		JTextArea txtweight = new JTextArea();
		txtweight.setBounds(122, 217, 160, 34);
		panel.add(txtweight);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(204, 497, 387, 82);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1_1_1_1 = new JLabel("ID");
		lblNewLabel_1_1_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1_1_1.setBounds(35, 30, 102, 41);
		panel_1.add(lblNewLabel_1_1_1_1);
		
		JTextArea txtID = new JTextArea();
		txtID.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					 
					String VID,Vcolour,Vweight,Vmodel;
					VID=txtID.getText();
					Vcolour=txtcolour.getText();
					Vweight=txtweight.getText();
					Vmodel=txtmodel.getText();
					
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from vehicles where V_ID=(?)");
	            	 pstmt1.setString(1, VID);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            	 txtID.setText(rs.getString(1));
	            	 txtmodel.setText(rs.getString(2));
	            	 txtcolour.setText(rs.getString(3));
	            	 txtweight.setText(rs.getString(4));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		txtID.setBounds(106, 23, 181, 48);
		panel_1.add(txtID);
		
		JButton btnNewButton = new JButton("UPDATE");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton) {
					String VID,Vcolour,Vweight,Vmodel;
					VID=txtID.getText();
					Vcolour=txtcolour.getText();
					Vweight=txtweight.getText();
					Vmodel=txtmodel.getText();
					
				
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update vehicles set  V_MODEL=(?),V_COLOUR=(?),V_WEIGHT=(?) where V_ID=(?)");
	            	 pstmt.setString(4, VID);
         	        pstmt.setString(1,Vmodel);
         	        pstmt.setString(2,Vcolour);
         	        pstmt.setString(3,Vweight);
	            	        int i=pstmt.executeUpdate();  
				    //txtmsg.append("\nInserted " + i + " rows successfully");
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(803, 301, 142, 53);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnExit = new JButton("VIEW");
		btnExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnExit) {
					fviewvehicles vs=new fviewvehicles();
				}
			}
		});
		btnExit.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnExit.setBounds(819, 418, 110, 53);
		frame.getContentPane().add(btnExit);
		
		JButton btnSave = new JButton("SAVE");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					
					String VID,Vcolour,Vweight,Vmodel;
					VID=txtID.getText();
					Vcolour=txtcolour.getText();
					Vweight=txtweight.getText();
					Vmodel=txtmodel.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into vehicles values (?,?,?,?)");
		            	        pstmt.setString(1, VID);
		            	        pstmt.setString(2,Vmodel);
		            	        pstmt.setString(3,Vcolour);
		            	        pstmt.setString(4,Vweight);
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnSave.setBounds(803, 77, 110, 46);
		frame.getContentPane().add(btnSave);
		
		JButton btnDelete = new JButton("DELETE");
		 btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnDelete) {
					String VID,Vcolour,Vweight,Vmodel;
					VID=txtID.getText();
					Vcolour=txtcolour.getText();
					Vweight=txtweight.getText();
					Vmodel=txtmodel.getText();
					
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from vehicles where V_ID=(?)");
		            	        pstmt.setString(1,VID);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnDelete.setBounds(801, 177, 128, 53);
		frame.getContentPane().add(btnDelete);
	}
}
