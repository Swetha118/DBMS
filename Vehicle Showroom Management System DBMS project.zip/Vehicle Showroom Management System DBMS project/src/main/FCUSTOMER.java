package main;



import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class FCUSTOMER {

	private JFrame frame;
	private JTextField nametxt;
	private JTextField contacttxt;
	private JTextField addresstxt;
	private JTextField VIDtxt;
	private JTextField mailtxt;
	private JTable table;


	/**
	 * Create the application.
	 */
	public FCUSTOMER() {
		initialize();
		this.frame.setVisible(true);
		Connect();
	}
	java.sql.Connection con;
	Statement stmt;
	ResultSet rs;
	
	 public void Connect()
	    {
		 try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
		 try 
			{
			 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Pass#123");
			  stmt = con.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(Color.PINK);
		frame.setBounds(100, 100, 1123, 632);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CUSTOMER");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 30));
		lblNewLabel.setBounds(427, -24, 337, 111);
		frame.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(119, 75, 436, 383);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel btnNewButton = new JLabel("cname");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton.setBounds(38, 55, 127, 38);
		panel.add(btnNewButton);
		
		JLabel btnNewButton_1 = new JLabel("VID");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_1.setBounds(38, 304, 127, 38);
		panel.add(btnNewButton_1);
		
		JLabel btnNewButton_2 = new JLabel("Address");
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBounds(38, 155, 127, 38);
		panel.add(btnNewButton_2);
		
		btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2.setBounds(38, 222, 127, 33);
		panel.add(btnNewButton_2);
		
		JLabel btnNewButton_3 = new JLabel("Contact");
		btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_3.setBounds(38, 143, 127, 33);
		panel.add(btnNewButton_3);
		
		nametxt = new JTextField();
		nametxt.setBounds(175, 57, 183, 38);
		panel.add(nametxt);
		nametxt.setColumns(10);
		
		contacttxt = new JTextField();
		contacttxt.setColumns(10);
		contacttxt.setBounds(175, 147, 183, 33);
		panel.add(contacttxt);
		
		addresstxt = new JTextField();
		addresstxt.setColumns(10);
		addresstxt.setBounds(175, 222, 183, 33);
		panel.add(addresstxt);
		
		VIDtxt = new JTextField();
		VIDtxt.setColumns(10);
		VIDtxt.setBounds(175, 311, 172, 33);
		panel.add(VIDtxt);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(null, "Search", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		panel_1.setBounds(148, 510, 383, 60);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JLabel btnNewButton_2_1 = new JLabel("mail");
		btnNewButton_2_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_2_1.setBounds(31, 11, 137, 38);
		panel_1.add(btnNewButton_2_1);
		
		mailtxt = new JTextField();
		mailtxt.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseReleased(MouseEvent e) {
				try {
					String name,contact,mail,address,VID;
					name=nametxt.getText();
					contact=contacttxt.getText();
					mail=mailtxt.getText();
					address=addresstxt.getText();
					VID=VIDtxt.getText();
					
					
	            	 PreparedStatement pstmt1 = con.prepareStatement("select * from customers where C_MAIL=(?)");
	            	 pstmt1.setString(1, mail);
	            	 ResultSet rs=pstmt1.executeQuery();
	            	 while(rs.next()) {
	            		
	            	 nametxt.setText(rs.getString(1));
	            	 contacttxt.setText(rs.getString(2));
	            	 mailtxt.setText(rs.getString(3));
	            	 addresstxt.setText(rs.getString(4));
		            VIDtxt.setText(rs.getString(5));
	            	 }
	            	        
				   
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
			
				
			}
		});
		mailtxt.setColumns(10);
		mailtxt.setBounds(201, 18, 172, 33);
		panel_1.add(mailtxt);
		
		JButton btnNewButton_4 = new JButton("SAVE");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				{
					
					String name,contact,mail,address,VID;
					name=nametxt.getText();
					contact=contacttxt.getText();
					mail=mailtxt.getText();
					address=addresstxt.getText();
					VID=VIDtxt.getText();
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("insert into customers values (?,?,?,?,?)");
		            	        pstmt.setString(1, name);
		            	        pstmt.setString(2,contact);
		            	        pstmt.setString(3,mail);
		            	        pstmt.setString(4,address);
		            	        pstmt.setString(5,VID);
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\nInserted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
				
				
			}
			}
		});
		btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_4.setBounds(730, 127, 111, 55);
		frame.getContentPane().add(btnNewButton_4);
		
		JButton btnNewButton_5 = new JButton("VIEW");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_5) {
					fviewcustomers vs=new fviewcustomers();
				}
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_5.setBounds(743, 428, 135, 45);
		frame.getContentPane().add(btnNewButton_5);
		
		JButton btnNewButton_6 = new JButton("UPDATE");
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_6) {
					String name,contact,mail,address,VID;
					name=nametxt.getText();
					contact=contacttxt.getText();
					mail=mailtxt.getText();
					address=addresstxt.getText();
					VID=VIDtxt.getText();
				
				try {
		            
	            	 PreparedStatement pstmt = con.prepareStatement("update  customers set  C_NAME=(?),C_CONTACT=(?),C_MAIL=(?),C_ADDRESS=(?) where V_ID=(?)");
	            	        pstmt.setString(5,VID);
	            	        pstmt.setString(1,name);
	            	        pstmt.setString(2,contact);
	            	        pstmt.setString(3,mail);
	            	        pstmt.setString(4,address);
	            	        int i=pstmt.executeUpdate();  
				    //txtmsg.append("\nInserted " + i + " rows successfully");
					JOptionPane.showMessageDialog(null, "\nupdated " + i + " rows successfully");
		   }
	            catch(Exception E)
	            { System.out.println(E);}  
		}
				
			}
		});
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_6.setBounds(739, 243, 122, 41);
		frame.getContentPane().add(btnNewButton_6);
		
		JButton btnNewButton_6_1 = new JButton("DELETE");
		btnNewButton_6_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnNewButton_6_1) {
					String name,contact,mail,address,VID;
					name=nametxt.getText();
					contact=contacttxt.getText();
					mail=mailtxt.getText();
					address=addresstxt.getText();
					VID=VIDtxt.getText();
					
					
					try {
			            
		            	 PreparedStatement pstmt = con.prepareStatement("delete from customers where C_MAIL=(?)");
		            	        pstmt.setString(1, mail);
		            	        
		            	        int i=pstmt.executeUpdate();  
					    //txtmsg.append("\nInserted " + i + " rows successfully");
						JOptionPane.showMessageDialog(null, "\ndeleted " + i + " rows successfully");
			   }
		            catch(Exception E)
		            { System.out.println(E);}  
			}
				
			}
		});
		btnNewButton_6_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnNewButton_6_1.setBounds(743, 342, 135, 32);
		frame.getContentPane().add(btnNewButton_6_1);
		
		table = new JTable();
		table.setBounds(724, 314, 135, -94);
		frame.getContentPane().add(table);
	}
}

