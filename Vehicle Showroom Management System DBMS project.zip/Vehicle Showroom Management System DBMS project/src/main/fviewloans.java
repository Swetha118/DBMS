package main;




import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.JTextPane;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

class fviewloans {

		private JFrame frame;
		private JTable table;
	    String[][] tbl=new String[100][100];
	    Connection con;
		Statement stmt;
		ResultSet rs;
		private JLabel loanIDtxt;
		private JLabel nametxt;
		private JLabel contacttxt;
		private JLabel VIdtxt;
		private JLabel amounttxt;
		/**
		 * Create the application.
		 */
		fviewloans() {
			try 
			{
				Class.forName("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB();
			initialize();
			this.frame.setVisible(true);
		}
		 void connectToDB() 
		    {
				try 
				{
				 con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","Pass#123");
				  stmt = con.createStatement();

				} 
				catch (SQLException connectException) 
				{
				  System.out.println(connectException.getMessage());
				  System.out.println(connectException.getSQLState());
				  System.out.println(connectException.getErrorCode());
				  System.exit(1);
				}
		    }
		/**
		 * Initialize the contents of the frame.
		 */
		private void initialize() {
			frame = new JFrame();
			frame.setBounds(100, 100, 797, 503);
			frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
			frame.getContentPane().setLayout(null);
			
			JTextPane txtpnOfficerDetails = new JTextPane();
			txtpnOfficerDetails.setFont(new Font("Tahoma", Font.BOLD, 21));
			txtpnOfficerDetails.setText("vehicle detatils");
			txtpnOfficerDetails.setBounds(227, 25, 239, 32);
			frame.getContentPane().add(txtpnOfficerDetails);
			try {
				ResultSet rs=stmt.executeQuery("select * from loans");
				
				int i=0;
				while(rs.next()) {
					
					
					
					tbl[i][0]=rs.getString(1);
					tbl[i][1]=rs.getString(2);
					tbl[i][2]=rs.getString(3); 
					tbl[i][3]=rs.getString(4);
					tbl[i][4]=rs.getString(5);
				
					i=i+1;
					
				}
				
				
			
			table = new JTable();
			table.setRowSelectionAllowed(false);
			table.setSurrendersFocusOnKeystroke(true);
			table.setModel(new DefaultTableModel(
				tbl,
				new String[] {
					"OFFICER ID", "NAME", "PHONENO"," ",""
				}
			));
			table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			table.setBounds(29, 137, 723, 121);
			frame.getContentPane().add(table);
			
			loanIDtxt = new JLabel("CID");
			loanIDtxt.setFont(new Font("Tahoma", Font.BOLD, 17));
			loanIDtxt.setBounds(48, 101, 235, 26);
			frame.getContentPane().add(loanIDtxt);
			
			nametxt = new JLabel("name");
			nametxt.setFont(new Font("Tahoma", Font.BOLD, 17));
			nametxt.setBounds(211, 92, 199, 45);
			frame.getContentPane().add(nametxt);
			
			contacttxt = new JLabel("contact");
			contacttxt.setFont(new Font("Tahoma", Font.BOLD, 17));
			contacttxt.setBounds(341, 101, 164, 26);
			frame.getContentPane().add(contacttxt);
			VIdtxt = new JLabel("VID");
			VIdtxt.setFont(new Font("Tahoma", Font.BOLD, 17));
			VIdtxt.setBounds(500, 101, 164, 26);
			frame.getContentPane().add(VIdtxt);
			amounttxt = new JLabel("amount");
			amounttxt.setFont(new Font("Tahoma", Font.BOLD, 17));
			amounttxt.setBounds(641, 101, 164, 26);
			frame.getContentPane().add(amounttxt);
			}
			catch(Exception E)
	        { 
	        	System.out.println(E);
	        }  
			
			
		}
	}

 